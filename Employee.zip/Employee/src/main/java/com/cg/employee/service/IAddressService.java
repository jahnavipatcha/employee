package com.cg.employee.service;

import com.cg.employee.entities.Address;

public interface IAddressService {

 public	Address addAddress(Address address);

// public	Address addAddressDetails(Address address, int empId);

}
